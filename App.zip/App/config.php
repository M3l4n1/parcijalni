<?php
return [
    'host' => 'localhost',
    'dbname' => 'ime_baze',
    'username' => 'root',
    'password' => '', 
];
