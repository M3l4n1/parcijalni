<?php
namespace App\Config;

class Config
{
    private static $settings = null;

    public static function get($key)
    {
        if (self::$settings === null) {
            self::$settings = include __DIR__ . '/../config.php';  
        }

        return self::$settings[$key] ?? null;
    }
}
