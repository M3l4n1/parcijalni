<?php

include 'autoload.php';

use App\Database\Database;

try {
    $db = Database::getInstance()->getConnection();
    echo "Uspješno spojeno na bazu!";
} catch (Exception $e) {
    echo "Došlo je do greške: " . $e->getMessage();
}
